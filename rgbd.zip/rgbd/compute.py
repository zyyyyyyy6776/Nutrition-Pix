import os
import cv2

def count_labels_in_masks(mask_directory):
    labels = set()

    for filename in os.listdir(mask_directory):
        if filename.endswith('.png'):  # 或者根据你的mask文件格式选择相应的扩展名
            mask_path = os.path.join(mask_directory, filename)
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)

            unique_labels = set(mask.flatten())
            labels.update(unique_labels)

    return len(labels)

# 调用函数，传入包含mask文件的目录路径
mask_directory = 'C:/users/17721/Desktop/output/output_train'
label_count = count_labels_in_masks(mask_directory)
print(f'Total labels count: {label_count}')