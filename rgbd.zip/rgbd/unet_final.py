# Copyright (c) 2020 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import paddle
import paddle.nn as nn
import paddle.nn.functional as F

from paddleseg import utils
from paddleseg.cvlibs import manager
from paddleseg.models import layers
from math import log

@manager.MODELS.add_component
class UNet(nn.Layer):
    """
    The UNet implementation based on PaddlePaddle.

    The original article refers to
    Olaf Ronneberger, et, al. "U-Net: Convolutional Networks for Biomedical Image Segmentation"
    (https://arxiv.org/abs/1505.04597).

    Args:
        num_classes (int): The unique number of target classes.
        align_corners (bool): An argument of F.interpolate. It should be set to False when the output size of feature
            is even, e.g. 1024x512, otherwise it is True, e.g. 769x769.  Default: False.
        use_deconv (bool, optional): A bool value indicates whether using deconvolution in upsampling.
            If False, use resize_bilinear. Default: False.
        pretrained (str, optional): The path or url of pretrained model for fine tuning. Default: None.
    """

    def __init__(self,
                 num_classes,
                 align_corners=False,
                 use_deconv=False,
                 pretrained=None):
        super().__init__()

        self.encode = Encoder()
        self.decode = Decoder(align_corners, use_deconv=use_deconv)
        self.cls = self.conv = nn.Conv2D(
            in_channels=64,
            out_channels=num_classes,
            kernel_size=3,
            stride=1,
            padding=1)
        self.pretrained = pretrained
        self.init_weight()

    def forward(self, x):
        logit_list = []
        x, short_cuts = self.encode(x)
        x = self.decode(x, short_cuts)
        logit = self.cls(x)
        logit_list.append(logit)
        return logit_list

    def init_weight(self):
        if self.pretrained is not None:
            utils.load_entire_model(self, self.pretrained)



'''class ECA(nn.Layer):
     """Constructs a ECA module in ECANet [4].
     Args:
         channel: Number of channels of the input feature map
         k_size: Adaptive selection of kernel size
     Return:
            return a refined feature map
     """
     def __init__(self, channel, k_size=3):
         super(ECA, self).__init__()
         self.avg_pool = nn.AdaptiveAvgPool2d(1)
         self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
         self.sigmoid = nn.Sigmoid()

     def forward(self, x):
         # feature descriptor on the global spatial information
         y = self.avg_pool(x)

         # Two different branches of ECA module
         y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)

         # Multi-scale information fusion
         y = self.sigmoid(y)
         x=x*y.expand_as(x)

         return x * y.expand_as(x)'''
class ECA(nn.Layer):
    def __init__(self,in_dim,gama=2,b=1):
        super(ECA,self).__init__()
        self.avgpool=nn.AdaptiveAvgPool2D(output_size=1)
        t=int(abs((log(in_dim,2)+b)/gama))
        #print(t)
        if t%2==0:
            k=t+1
        else:
            k=t
        print(k)
        #print(k)
        self.conv=nn.Conv1D(in_channels=1,out_channels=1,kernel_size=k,stride=1,padding=int(k/2),groups=1,bias_attr=False)
        self.act=nn.Sigmoid()
    def forward(self,inputs):
        #print(inputs.shape)
        x = paddle.unsqueeze(inputs,axis=-1)
        x=paddle.transpose(x,[0,2,1])
        x=self.conv(x)
        x=paddle.transpose(x,[0,2,1])
        x = paddle.squeeze(x,axis=-1)
        return x#expand_as作用是将输入tensor的维度扩展为与指定tensor相同的size,其实这里不加也可


class SE(nn.Layer):
    """ SE attention module in SENet [1].
        Args:
            channel: the number of channels
            reduction: a parameter to control model complexity
        Return:
            return a refined feature map
    """
    def __init__(self, channel, reduction=16):
        super(SE, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2D(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel * reduction),
            nn.ReLU(),            
            nn.Linear(channel * reduction, channel),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.shape
        y = self.avg_pool(x).reshape([b,c])
        #print(y.shape)
        y = self.fc(y).reshape([b,c,1,1])
        return x * y


class Resblock(nn.Layer):
    """ resblock
    """
    def __init__(self, in_channel, out_channel):
        super(Resblock, self).__init__()
        self.conv1 = nn.Conv2D(in_channel, out_channel, 1)

        self.conv2 = nn.Conv2D(out_channel, out_channel, 1)
        self.bn1 = nn.BatchNorm2D(out_channel)
        self.bn2 = nn.BatchNorm2D(out_channel)
        self.skip =  nn.Conv2D(in_channel, out_channel, 1)
    def forward(self, x):

        y = self.conv1(x)
        y = self.bn1(y)
        y = self.conv2(y)
        y = self.bn2(y)
        x = self.skip(x)
        return F.relu(x+y)

class Res(nn.Layer):
    """ resblock
    """
    def __init__(self, in_channel, out_channel):
        super(Res, self).__init__()
        self.conv1 = layers.ConvBNReLU(in_channel, out_channel, 1)

        self.conv2 = layers.ConvBNReLU(out_channel, out_channel*4, 3)
        self.conv3 = nn.Conv2D(out_channel*4, out_channel, 1)
        self.bn = nn.BatchNorm2D(out_channel)
        self.skip =  nn.Conv2D(in_channel, out_channel, 1)
    def forward(self, x):

        y = self.conv1(x)
        y = self.conv2(y)
        y = self.conv3(y)
        y = self.bn(y)
        x = self.skip(x)
        out = F.relu(x+y)
        return out


class Encoder(nn.Layer):
    def __init__(self):
        super().__init__()

        self.double_conv = nn.Sequential(#Res(3, 64))
            layers.ConvBNReLU(3, 64, 3), layers.ConvBNReLU(64, 64, 3))
        self.double_conv2 = nn.Sequential(#Res(3, 64))
            layers.ConvBNReLU(3, 64, 3), layers.ConvBNReLU(64, 64, 3))
        down_channels = [[64, 128], [128, 256], [256, 512], [512, 512]]
        self.down_sample_list = nn.LayerList([
            self.down_sampling(channel[0], channel[1])
            for channel in down_channels
        ])

        self.down_sample_list2 = nn.LayerList([
            self.down_sampling(channel[0], channel[1])
            for channel in down_channels
        ])

        self.att_list = nn.LayerList([
            SE(channel[0])
            for channel in down_channels
        ])

        self.att = SE(3)
        self.att2 = SE(3)
    def down_sampling(self, in_channels, out_channels):
        modules = []
        modules.append(nn.MaxPool2D(kernel_size=2, stride=2))
        modules.append(Res(in_channels, out_channels))
        #modules.append(layers.ConvBNReLU(in_channels, out_channels, 3))
        #modules.append(layers.ConvBNReLU(out_channels, out_channels, 3))
        return nn.Sequential(*modules)

    def forward(self, x):
        short_cuts = []
        short_cuts2 = []
        rgb, depth = paddle.split(x, num_or_sections=2, axis = 1)
        depth = self.double_conv((depth))

        rgb = self.double_conv2((rgb))
        x = rgb 
        for i, down_sample in enumerate(self.down_sample_list):
            #print(i)
            x = x + (self.att_list[i])(depth)
            short_cuts.append(x)
            x = down_sample(x)
            depth = (self.down_sample_list2[i])(depth)


        return x, short_cuts








class Decoder(nn.Layer):
    def __init__(self, align_corners, use_deconv=False):
        super().__init__()

        up_channels = [[512, 256], [256, 128], [128, 64], [64, 64]]
        self.up_sample_list = nn.LayerList([
            UpSampling(channel[0], channel[1], align_corners, use_deconv)
            for channel in up_channels
        ])

    def forward(self, x, short_cuts):
        for i in range(len(short_cuts)):
            x = self.up_sample_list[i](x, short_cuts[-(i + 1)])
        return x

class MHSA(nn.Layer): 

    def __init__(self, n_dims, height, width):
        super(MHSA, self).__init__()
        self.qkv = nn.Conv2D(n_dims, n_dims*3, 1)
        self.h = self.create_parameter(shape=(1, n_dims, height, 1))
        self.add_parameter("h", self.h)
        self.w = self.create_parameter(shape=(1, n_dims, 1, width))
        self.add_parameter("w", self.w)
        self.bn = nn.BatchNorm2D(n_dims)
        self.act = nn.ReLU()

    def forward(self, x):
        N, C, H, W = x.shape
        qkv = self.qkv(x).reshape([N, C*3, H*W])
        q = qkv[:, :qkv.shape[1]//3, :]
        k = qkv[:, qkv.shape[1]//3 : qkv.shape[1]//3*2, :]
        v = qkv[:, qkv.shape[1]//3*2:, :]
        content_content = paddle.bmm(k.transpose([0,2,1]), q)
        content_position = (self.h + self.w).reshape([1, C, -1])
        content_position = paddle.matmul(q.transpose([0,2,1]), content_position)
        energy = content_content + content_position
        attention = F.softmax(energy, 1)
        y = paddle.bmm(v, attention).reshape([N, C, H, W])
        y = self.bn(y)
        y = self.act(y)
        return y




def window_partition(x, window_size):
    B, H, W, C = x.shape # 这里的H, W应该是经过patchembedding之后的h'和w'
    # 按照顺序进行window的划分
    x = x.reshape([B, H // window_size, window_size, W // window_size, window_size, C])
    x = x.transpose([0, 1, 3, 2, 4, 5])
    # x:[B, h//ws, w//ws, ws, ws, c]
    x = x.reshape([-1, window_size, window_size,C])
    # 相当于把每个window当做一个图像了
    return x

# 窗口自注意力做完之后，恢复到原始图片
def window_reverse(windows, window_size, H, W):
    # 上面那个函数将num_window合并到batch维度了，这里需要先计算出batchsize
    B = int(windows.shape[0] // (H // window_size * W // window_size))
    x = windows.reshape([B, H // window_size, window_size, W // window_size, window_size, -1])
    x = x.transpose([0, 1, 3, 2, 4, 5])
    x = x.reshape([B, H, W, -1])
    return x




class Mlp(nn.Layer):
    def __init__(self, embed_dim, mlp_ratio=4.0, dropout=0.):
        super().__init__()
        self.fc1 = nn.Linear(embed_dim, int(mlp_ratio * embed_dim))
        self.fc2 = nn.Linear(int(mlp_ratio * embed_dim), embed_dim)
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # x:[B, num_patchs, embed_dim]
        x = self.fc1(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = self.dropout(x)
        return x

class WindowAttention(nn.Layer):
    def __init__(self,
                 embed_dim,
                 window_size,
                 num_heads,
                 qkv_bias=True,
                 qk_scale=None,
                 attention_dropout=0.,
                 dropout=0.):
        super().__init__()

        self.window_size = window_size
        self.num_heads = num_heads
        self.embed_dim = embed_dim

        self.embed_dim_head = embed_dim // num_heads # 每个头的维度
        self.scale = qk_scale or self.embed_dim_head ** -0.5  # 根号d(每个头的d)

        # 生成相对位置编码表，每个头单独学习，以便查表(2M-1) * (2M-1), M = 7
        self.relative_position_bias_table = paddle.create_parameter(
            shape=[(2 * window_size -1) * (2 * window_size - 1), num_heads],
            dtype='float32',
            default_initializer=paddle.nn.initializer.TruncatedNormal(std=.02))

        # 生成相对位置编码
        coords_h = paddle.arange(self.window_size)
        coords_w = paddle.arange(self.window_size)
        coords = paddle.stack(paddle.meshgrid([coords_h, coords_w]))  # [2, window_h, window_w]:[2, 7, 7]
        coords_flatten = paddle.flatten(coords, 1)  # [2, window_h * window_w]
        # 列向量减去行向量然后先广播再做差: [2, window_h * window_w, window_h * window_w]
        relative_coords = coords_flatten.unsqueeze(2) - coords_flatten.unsqueeze(1)
        # [winwod_h*window_w, window_h*window_w, 2]
        relative_coords = relative_coords.transpose([1, 2, 0])

        relative_coords[:, :, 0] += self.window_size - 1
        relative_coords[:, :, 1] += self.window_size - 1
        # 索引全部映射到正数
        relative_coords[:, :, 0] *= 2 * self.window_size - 1  # 取正值

        # [window_size * window_size, window_size*window_size]
        relative_position_index = relative_coords.sum(-1) # 将最后两个维度求和得到索引
        # 将普通tensor注册为持久变量，不会被更新，但是会被写入静态图
        self.register_buffer("relative_position_index", relative_position_index) 

        w_attr_1, b_attr_1 = self._init_weights() # qkv初始化权重
        self.qkv = nn.Linear(embed_dim,
                             embed_dim * 3,
                             weight_attr=w_attr_1,
                             bias_attr=b_attr_1 if qkv_bias else False)

        self.attn_dropout = nn.Dropout(attention_dropout)

        w_attr_2, b_attr_2 = self._init_weights() # 多头合并投射层初始化权重
        self.proj = nn.Linear(embed_dim,
                              embed_dim,
                              weight_attr=w_attr_2,
                              bias_attr=b_attr_2)
        
        self.proj_dropout = nn.Dropout(dropout)
        self.softmax = nn.Softmax(axis=-1)

    def _init_weights(self):
        weight_attr = paddle.ParamAttr(initializer=paddle.nn.initializer.TruncatedNormal(std=.02))
        bias_attr = paddle.ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))
        return weight_attr, bias_attr

    def transpose_multihead(self, x):
        new_shape = x.shape[:-1] + [self.num_heads, self.embed_dim_head]
        x = x.reshape(new_shape)
        # [B, num_heads, num_patches, embed_dim_head]
        x = x.transpose([0, 2, 1, 3])
        return x

    def get_relative_pos_bias_from_pos_index(self):
        # 查表函数
        table = self.relative_position_bias_table  # [13*13, num_heads]
        # index is a tensor
        index = self.relative_position_index.reshape([-1])  # [window_h*window_w * window_h*window_w]
        # 通过tensor索引，返回相应的tensor
        relative_position_bias = paddle.index_select(x=table, index=index)
        return relative_position_bias

    def forward(self, x, mask=None):
        #x: [B, num_patches, embed_dim]
        qkv = self.qkv(x).chunk(3, axis=-1) 
        # q, k, v:[B, num_heads, num_patches, embed_dim_head]
        q, k, v = map(self.transpose_multihead, qkv)
        q = q * self.scale
        attn = paddle.matmul(q, k, transpose_y=True) # 产生attn权重:[B, num_heads, num_patches, num_patches]

        # 获得attn所有位置的相对位置编码
        relative_position_bias = self.get_relative_pos_bias_from_pos_index()
        # RPE:[49, 49, num_heads]
        relative_position_bias = relative_position_bias.reshape(
            [self.window_size * self.window_size,
             self.window_size * self.window_size,
             -1])

        # relative_position_bias:[num_heads, window_h*window_w, window_h*window_w]
        relative_position_bias = relative_position_bias.transpose([2, 0, 1])

        attn = attn + relative_position_bias.unsqueeze(0) # 对计算的attn添加相对位置编码,unsqueeze(0)代表所有样本编码一致

        # 下面进行窗口mask，这里仅在SW-MSA才需要
        if mask is not None:
            nW = mask.shape[0]
            attn = attn.reshape(
                [x.shape[0] // nW, nW, self.num_heads, x.shape[1], x.shape[1]])
            attn += mask.unsqueeze(1).unsqueeze(0)
            attn = attn.reshape([-1, self.num_heads, x.shape[1], x.shape[1]])
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_dropout(attn)

        z = paddle.matmul(attn, v) # 计算注意力加权和
        z = z.transpose([0, 2, 1, 3])
        # 多头合并
        new_shape = z.shape[:-2] + [self.embed_dim]
        z = z.reshape(new_shape)
        # 等维度投射一下
        z = self.proj(z)
        z = self.proj_dropout(z)

        return z


class SwinTransformerBlock(nn.Layer):
    def __init__(self, embed_dim, input_resolution, num_heads, window_size, shift_size=0, mlp_ratio=4.0, 
        qkv_bias=True, qk_scale=None, dropout=0., attention_dropout=0.,droppath=0.):
        super().__init__()
        self.embed_dim = embed_dim
        self.window_size = window_size
        self.shift_size = shift_size
        self.resolution = input_resolution

        self.attn_norm = nn.LayerNorm(embed_dim)
        self.attn = WindowAttention(embed_dim, window_size, num_heads)

        self.mlp_norm = nn.LayerNorm(embed_dim)
        self.mlp = Mlp(embed_dim, mlp_ratio=mlp_ratio)
        
        if min(self.resolution) <= self.window_size:
            self.shift_size = 0
            self.window_size = min(self.resolution)
        # 制作mask，张量操作，同样是利用了广播操作
        if self.shift_size > 0:
            H, W = self.resolution
            img_mask = paddle.zeros((1, H, W, 1))
            h_slices = (slice(0, -self.window_size),
                        slice(-self.window_size, -self.shift_size),
                        slice(-self.shift_size, None))
            w_slices = (slice(0, -self.window_size),
                        slice(-self.window_size, -self.shift_size),
                        slice(-self.shift_size, None))
            cnt = 0
            for h in h_slices:
                for w in w_slices:
                    img_mask[:, h, w, :] = cnt
                    cnt += 1

            mask_windows = window_partition(img_mask, self.window_size)
            mask_windows = mask_windows.reshape((-1, self.window_size * self.window_size))
            attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
            # 对于减完之后非零的位置填充-100，零的地方为零
            attn_mask = paddle.where(attn_mask != 0,
                                     paddle.ones_like(attn_mask) * float(-100.0),
                                     attn_mask)
            attn_mask = paddle.where(attn_mask == 0,
                                     paddle.zeros_like(attn_mask),
                                     attn_mask)
        else:
            attn_mask = None

        self.register_buffer("attn_mask", attn_mask)

    def forward(self, x):
        H, W  = self.resolution # 图像处理成patch之后的长宽
        B, N, C = x.shape # 输入[batch, num_patchs, embed_dim]
        # W-MSA
        h = x
        x = self.attn_norm(x)
        # x:[B, num_patchs, embed_dim]
        # 接下来需要进行关键的attn计算，这里我们需要判断是否需要移动窗口
        x = x.reshape([B, H, W, C])
        if self.shift_size > 0:
            shifted_x = paddle.roll(x, shifts=(-self.shift_size,-self.shift_size), axis=(1, 2)) # 在H和W方向进行滚动
        else:
            shifted_x = x
        # 计算窗口自注意力 x:[B, H, W, C]
        x_windows = window_partition(shifted_x, window_size=self.window_size) # x:[B', ws, ws, C]
        x_windows = x_windows.reshape([-1, self.window_size * self.window_size, C])
        attn_windows = self.attn(x_windows, mask=self.attn_mask)
        attn_windows = attn_windows.reshape([-1, self.window_size, self.window_size, C]) # x:[B', ws, ws, C]
        shifted_x = window_reverse(attn_windows, self.window_size, H, W) # x:[B, H, W, C]
        # 滚动回溯
        if self.shift_size > 0:
            x = paddle.roll(shifted_x, shifts=(self.shift_size, self.shift_size), axis=(1,2))
        else:
            x = shifted_x
        x = x.reshape([B, H*W, C])
        # shortcut
        x = x + h

        # MLP
        h = x
        x = self.mlp_norm(x)
        x = self.mlp(x)
        x = x + h
        return x


class MultiHeadAttention(nn.Layer):

    def __init__(self, d_model, nhead, dropout=0): 
        super().__init__()
        self.d_model = d_model
        self.nhead = nhead
        self.wqkv = nn.Linear(d_model, d_model*3)
        self.drop_attn = nn.Dropout(dropout)
        self.fc = nn.Linear(d_model, d_model)
        self.drop_fc = nn.Dropout(dropout)
        self.norm = nn.LayerNorm([d_model])
        
    def forward(self, x):
        B, T, C = x.shape
        qkv = self.wqkv(x).reshape([B, T, 3, self.nhead, C//self.nhead]).transpose([2,0,3,1,4])
        q, k, v = qkv[0], qkv[1], qkv[2]
        shortcut = q
        attn = paddle.matmul(q, k, transpose_y=True) * (self.d_model // self.nhead)**-0.5
        attn = F.softmax(attn, axis=-1)
        attn = self.drop_attn(attn)
        q = paddle.matmul(attn, v).transpose([0,2,1,3]).reshape([B,T,C])
        q = self.drop_fc(self.fc(q))
        q += shortcut.transpose([0,2,1,3]).reshape([B,T,C])
        q = self.norm(q)
        return q

class Attention(paddle.nn.Layer):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super(Attention,self).__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.attend = nn.Softmax(axis = -1)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias_attr = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()
    def forward(self, x):
        b, n, _, h = *x.shape, self.heads
        qkv = self.to_qkv(x)
        qkv = paddle.chunk(qkv,chunks=3,axis=-1)#把tensor切割成三分，生成list
        #q, k, v = map(rearrange_for_qkv,(qkv,h))#传播函数，把list中的每一个都应用到rearrange函数中
        q = rearrange_for_qkv(qkv[0],h)
        k = rearrange_for_qkv(qkv[1],h)
        v = rearrange_for_qkv(qkv[2],h)
        dots = paddle.fluid.layers.matmul(q,k,transpose_x=False,transpose_y=True)* self.scale
        attn = self.attend(dots)
        out = paddle.fluid.layers.matmul(attn,v)
        out = rearrange_for_out(out)
        return self.to_out(out)
class spatt(nn.Layer):
    """ SE attention module in SENet [1].
        Args:
            channel: the number of channels
            reduction: a parameter to control model complexity
        Return:
            return a refined feature map
    """
    def __init__(self, d_model, nhead=8):
        super(spatt, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2D(1)
        self.former_att = MultiHeadAttention(d_model, nhead)
        self.act = nn.Sigmoid()
    def forward(self, x):
        short = x
        mean_out = paddle.mean(x, axis=1, keepdim=False)#B 1 h w
        max_out = paddle.max(x, axis=1, keepdim=False)
        x = mean_out + max_out
        #print(x.shape)
        x = self.former_att(x)    
        x = paddle.unsqueeze(x,axis=-3)  
        x = self.act(x)

        return short * x


class UpSampling(nn.Layer):
    def __init__(self,
                 in_channels,
                 out_channels,
                 align_corners,
                 use_deconv=False):
        super().__init__()

        self.align_corners = align_corners

        self.use_deconv = use_deconv
        if self.use_deconv:
            self.deconv = nn.Conv2DTranspose(
                in_channels,
                out_channels // 2,
                kernel_size=2,
                stride=2,
                padding=0)
            in_channels = in_channels + out_channels // 2
        else:
            in_channels *= 2

        self.double_conv = nn.Sequential(#Res(in_channels, out_channels))
            layers.ConvBNReLU(in_channels, out_channels, 3),
            spatt(int(32768/in_channels)),
            layers.ConvBNReLU(out_channels, out_channels, 3))
        self.proj = nn.Conv2D(in_channels//2, in_channels//2, 1)
    def forward(self, x, short_cut):
        if self.use_deconv:
            x = self.deconv(x)
        else:
            x = F.interpolate(
                x,
                paddle.shape(short_cut)[2:],
                mode='bilinear',
                align_corners=self.align_corners)
        x = paddle.concat([x, self.proj(short_cut)], axis=1)
        #print(x.shape)
        x = self.double_conv(x)
        return x
