import paddle
import os
from paddleseg.models import UNetPlusPlus,UNet
import matplotlib.pyplot as plt
from paddle.io import Dataset
from paddleseg.transforms import Compose, Resize, Normalize, RandomHorizontalFlip, RandomVerticalFlip, RandomRotation, RandomScaleAspect, RandomDistort
import cv2
from paddleseg.models.losses import BCELoss,CrossEntropyLoss,DiceLoss,MixedLoss
from paddleseg.core import train
import numpy as np
import paddleseg.transforms as T


class ChangeDataset(Dataset):
    # 这里的transforms、num_classes和ignore_index需要，避免PaddleSeg在Eval时报错
    def __init__(self, dataset_path, mode, transforms=[], num_classes=14, ignore_index=255):
        list_path = os.path.join(dataset_path, (mode + '_list.txt'))
        self.data_list = self.__get_list(list_path)
        self.data_num = len(self.data_list)
        self.transforms = Compose(transforms, to_rgb=False)  # 这里实际没有使用transforms，因为通道数不为3通道，直接使用PaddleSeg的不行
        self.num_classes = num_classes  # 分类数
        self.ignore_index = ignore_index  # 忽视的像素值
    def __getitem__(self, index):
        A_path, B_path, lab_path = self.data_list[index]
        A_img = cv2.cvtColor(cv2.imread(A_path), cv2.COLOR_BGR2RGB)
        B_img = cv2.cvtColor(cv2.imread(B_path), cv2.COLOR_BGR2RGB)
        image = np.concatenate((A_img, B_img), axis=-1)  # 将两个时段的数据concat在通道层
        label = cv2.imread(lab_path, cv2.IMREAD_GRAYSCALE)
        image, label = self.transforms(im=image, label=label)
        #label = label.clip(max=1)  # 这里把0-255变为0-1，否则啥也学不到，计算出来的Kappa系数还为负数
        image = paddle.to_tensor(image).astype('float32')
        #label = paddle.to_tensor(label[np.newaxis, :]).astype('int64')
        label = paddle.to_tensor(label).astype('int64')
        #print(label.shape)
        return image, label
    def __len__(self):
        return self.data_num
    # 这个用于把list.txt读取并转为list
    def __get_list(self, list_path):
        data_list = []
        with open(list_path, 'r') as f:
            data = f.readlines()
            for d in data:
                data_list.append(d.replace('\n', '').split(' '))
            print(data_list)
        return data_list

dataset_path = 'dataset'
# 完成三个数据的创建
#transforms = [Resize([256,256]), RandomHorizontalFlip(), RandomVerticalFlip(), RandomRotation(),RandomScaleAspect(), RandomDistort(), Normalize()]
train_transforms = [  
    T.RandomHorizontalFlip(),  # 水平翻转
    #T.RandomVerticalFlip(),  # 垂直翻转
    # T.RandomScaleAspect(),  # 随机缩放
    # T.RandomRotation(),  # 随机旋转
    T.Resize(target_size=(256, 256)), 
    T.Normalize(mean=[0.5]*6, std=[0.5]*6)   # 归一化
]

# 构建验证集
val_transforms = [
    #T.RandomHorizontalFlip(),  # 水平翻转
    #T.RandomVerticalFlip(),  # 垂直翻转
    # T.RandomScaleAspect(),  # 随机缩放
    # T.RandomRotation(),  # 随机旋转
    T.Resize(target_size=(256, 256)),
    T.Normalize(mean=[0.5]*6, std=[0.5]*6)   # 归一化
]

test_transforms = [
    #T.RandomHorizontalFlip(),  # 水平翻转
    #T.RandomVerticalFlip(),  # 垂直翻转
    # T.RandomScaleAspect(),  # 随机缩放
    # T.RandomRotation(),  # 随机旋转
    T.Resize(target_size=(256, 256)),
    #T.Normalize(mean=[0.5]*6, std=[0.5]*6)   # 归一化
]

#transforms = [Resize([256,256])]
train_data = ChangeDataset(dataset_path, 'train', train_transforms)

val_data = ChangeDataset(dataset_path, 'val', val_transforms)


test_data = ChangeDataset(dataset_path, 'val', test_transforms)

model_path = '/home/mprl1/An/rgbd/best_model/our_model_rgb_86.5/model.pdparams'
#model_path = './output2/best_model/model.pdparams'  # 加载得到的最好参数
model = UNet(num_classes=14, use_deconv=False)
para_state_dict = paddle.load(model_path)
model.set_dict(para_state_dict)
#test_data= '/home/mprl1/An/rgbd/dataset/test_data/000064.png'
for idx, (img, lab) in enumerate(test_data):  # 从test_data来读取数据
    
    #print(img.shape) 
    if idx == 129:  # 查看第三个
        m_img = img.reshape((1, 6, 256, 256))
        m_img2 = val_data[idx][0].reshape((1, 6, 256, 256))
        m_pre = model(m_img2)
        #print(m_pre[0].shape)
        s_img = img.reshape((6, 256, 256)).numpy().transpose(1, 2, 0)
        # 拆分6通道为两个3通道图像
        s_A_img = s_img[:,:,0:3]
        s_B_img = s_img[:,:,3:6]
        lab_img = lab.reshape((256, 256)).numpy()
        #pre_img = m_pre.reshape((256, 256)).numpy()
        pre_img = paddle.argmax(m_pre[0], axis=1).reshape((256, 256)).numpy()
        plt.figure(figsize=(10, 10))
        plt.subplot(2,2,1);plt.imshow(s_A_img.astype('int64'));plt.title('RGB')
        plt.subplot(2,2,2);plt.imshow(s_B_img.astype('int64'));plt.title('Depth')
        plt.subplot(2,2,3);plt.imshow(lab_img);plt.title('Ground Truth')
        plt.subplot(2,2,4);plt.imshow(pre_img);plt.title('Ours')
        plt.show()
        break  # 只看一个结果就够了
