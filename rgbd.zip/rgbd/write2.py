import shutil

root1 = r"./voc/JPEGImages"
root2 = r"./voc/depth_color"
root3 = r"./voc/SegmentationClass"
dst1 = r"./dataset/train/T1"
dst2 = r"./dataset/train/T2"
dst3 = r"./dataset/train/label"


f3 = open('train.txt', encoding = 'utf-8')
cont_train = f3.readlines()
#print(cont)
f3.close
f2 = open('val.txt', encoding = 'utf-8')
cont_test = f2.readlines()
print(cont_test)
f2.close


#分别写入train.txt, test.txt	
with open('train1.txt', 'w') as f1, open('test1.txt', 'w') as f4:
    for id,i in enumerate(cont_train):
        #print(i)
        #filename = []
        #dst = []
        filename = root1 + '/' + i[:-1] +'.png'
        #print(filename)
        dst = dst1 + '/' + i[:-1] +'.png'
        shutil.copy(filename,dst)

        filename2 = root2 + '/' + i[:-1] +'.png'
        dst_2 = dst2 + '/' + i[:-1] +'.png'
        shutil.copy(filename2,dst_2)

        filename3 = root3 + '/' + i[:-1] +'.png'
        dst_3 = dst3 + '/' + i[:-1] +'.png'
        shutil.copy(filename3,dst_3)

'''        f1.write('.npy')
        f1.write(' ')
        f1.write('./data/depths/')
        f1.write(i[:-1])
        f1.write('.npy')
        f1.write(' ')
        f1.write('./data/labels/')
        f1.write(i[:-1])
        f1.write('.npy')
        f1.write('\n')
     
    for id,j in enumerate (cont_test):
        print(j)
        f4.write('./data/images/')
        f4.write(j[:-1])
        f4.write('.npy')
        f4.write(' ')
        f4.write('./data/depths/')
        f4.write(j[:-1])
        f4.write('.npy')
        f4.write(' ')
        f4.write('./data/labels/')
        f4.write(j[:-1])
        f4.write('.npy')
        f4.write('\n')'''

print('成功！')
