# 构建数据集
import os
os.environ["CUDA_VISIBLE_DEVICES"]='0'
import cv2
import numpy as np
import paddle
from paddle.io import Dataset
from paddleseg.transforms import Compose, Resize, Normalize, RandomHorizontalFlip, RandomVerticalFlip, RandomRotation, RandomScaleAspect, RandomDistort
from paddleseg.models import UNetPlusPlus,UNet
from paddleseg.models.losses import BCELoss,CrossEntropyLoss,DiceLoss,MixedLoss
from paddleseg.core import train

import paddleseg.transforms as T


class ChangeDataset(Dataset):
    # 这里的transforms、num_classes和ignore_index需要，避免PaddleSeg在Eval时报错
    def __init__(self, dataset_path, mode, transforms=[], num_classes=14, ignore_index=255):
        list_path = os.path.join(dataset_path, (mode + '_list.txt'))
        self.data_list = self.__get_list(list_path)
        self.data_num = len(self.data_list)
        self.transforms = Compose(transforms, to_rgb=False)  # 这里实际没有使用transforms，因为通道数不为3通道，直接使用PaddleSeg的不行
        self.num_classes = num_classes  # 分类数
        self.ignore_index = ignore_index  # 忽视的像素值
    def __getitem__(self, index):
        A_path, B_path, lab_path = self.data_list[index]
        A_img = cv2.cvtColor(cv2.imread(A_path), cv2.COLOR_BGR2RGB)
        B_img = cv2.cvtColor(cv2.imread(B_path), cv2.COLOR_BGR2RGB)
        image = np.concatenate((A_img, B_img), axis=-1)  # 将两个时段的数据concat在通道层
        label = cv2.imread(lab_path, cv2.IMREAD_GRAYSCALE)
        image, label = self.transforms(im=image, label=label)
        #label = label.clip(max=1)  # 这里把0-255变为0-1，否则啥也学不到，计算出来的Kappa系数还为负数
        image = paddle.to_tensor(image).astype('float32')
        #label = paddle.to_tensor(label[np.newaxis, :]).astype('int64')
        label = paddle.to_tensor(label).astype('int64')
        #print(label.shape)
        return image, label
    def __len__(self):
        return self.data_num
    # 这个用于把list.txt读取并转为list
    def __get_list(self, list_path):
        data_list = []
        with open(list_path, 'r') as f:
            data = f.readlines()
            for d in data:
                data_list.append(d.replace('\n', '').split(' '))
            print(data_list)
        return data_list

dataset_path = 'dataset'
# 完成三个数据的创建
#transforms = [Resize([256,256]), RandomHorizontalFlip(), RandomVerticalFlip(), RandomRotation(),RandomScaleAspect(), RandomDistort(), Normalize()]
train_transforms = [  
    T.RandomHorizontalFlip(),  # 水平翻转
    #T.RandomVerticalFlip(),  # 垂直翻转
    # T.RandomScaleAspect(),  # 随机缩放
    # T.RandomRotation(),  # 随机旋转
    T.Resize(target_size=(256, 256)), 
    T.Normalize(mean=[0.5]*6, std=[0.5]*6)   # 归一化
]

# 构建验证集
val_transforms = [
    #T.RandomHorizontalFlip(),  # 水平翻转
    #T.RandomVerticalFlip(),  # 垂直翻转
    # T.RandomScaleAspect(),  # 随机缩放
    # T.RandomRotation(),  # 随机旋转
    T.Resize(target_size=(256, 256)),
    T.Normalize(mean=[0.5]*6, std=[0.5]*6)   # 归一化
]


#transforms = [Resize([256,256])]
train_data = ChangeDataset(dataset_path, 'train', train_transforms)

val_data = ChangeDataset(dataset_path, 'val', val_transforms)



# 参数、优化器及损失
epochs = 200
batch_size = 8
iters = 1250 // batch_size * 200
base_lr = 2e-4

mixtureLosses = [CrossEntropyLoss(),DiceLoss()]
mixtureCoef=[0.3,0.7]

losses = {}
#losses['types'] = [CrossEntropyLoss()]
losses['types'] = [MixedLoss(mixtureLosses,mixtureCoef)]
losses['coef'] = [1]

#model = UNet(num_classes=14, use_deconv=False)
model = UNetPlusPlus(in_channels=3, num_classes=14, use_deconv=False)
# paddle.summary(model, (1, 6, 1024, 1024))  # 可查看网络结构
lr = paddle.optimizer.lr.CosineAnnealingDecay(base_lr, T_max=(iters // 3), last_epoch=0.5)  # 余弦衰减
optimizer = paddle.optimizer.Adam(lr, parameters=model.parameters())  # Adam优化器
# 训练
train(
    model=model,
    train_dataset=train_data,
    val_dataset=val_data,
    optimizer=optimizer,
    save_dir='output2',
    iters=iters,
    batch_size=batch_size,
    save_interval=int(iters/100),  # 总共保存10个模型
    log_iters=100, #print frequency
    num_workers=0,
    losses=losses,
    use_vdl=True)


